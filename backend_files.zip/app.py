import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
import tensorflow as tf
import joblib
from tensorflow.keras.models import load_model
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Global variables for lazy loading
model = None
label_encoders = None
scaler = None
model_columns = None

def load_models():
    """Lazy loading to avoid startup timeout"""
    global model, label_encoders, scaler, model_columns
    
    if model is None:
        try:
            logger.info("Loading models...")
            
            # FIXED: Use relative paths since app.py is inside backend_files
            model = load_model("best_model_adam.h5", compile=False)
            label_encoders = joblib.load("label_encoders.joblib")
            scaler = joblib.load("sc.joblib")
            model_columns = joblib.load("model_columns.joblib")
            
            logger.info("Models loaded successfully.")
            
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            raise e
    
    return model, label_encoders, scaler, model_columns

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy"})

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Load models on first request (prevents startup timeout)
        model, label_encoders, scaler, model_columns = load_models()
        
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
            
        df = pd.DataFrame([data])
        df = df.drop(columns=['RowNumber', 'CustomerId', 'Surname'], errors='ignore')
        
        for col, encoder in label_encoders.items():
            if col in df.columns:
                df[col] = encoder.transform(df[col])
        
        df = df.reindex(columns=model_columns, fill_value=0)
        df[['Balance', 'EstimatedSalary']] = scaler.transform(df[['Balance', 'EstimatedSalary']])
        

        pred_prob = model.predict(df)[0][0]
        prediction = int(pred_prob > 0.5)
        return jsonify({"Prediction": prediction})

    except Exception as e:
        # Add error handling for robustness
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
